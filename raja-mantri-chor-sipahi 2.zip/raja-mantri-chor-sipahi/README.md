# Raja Mantri Chor Sipahi — Real-time Multiplayer

Classic Indian party game for exactly 4 players. Join with a 4-letter room code, no login, no app install. Works on phones and laptops.

## Run locally
```
npm install
npm start        # http://localhost:8000
```
Open 4 browser windows (or phones on the same network) to play.

## Files
- `server.js` — Node.js HTTP + WebSocket (`ws`) server. Authoritative game state, room codes, timers, scoring, reconnect.
- `public/index.html` — page shell, fonts, header (language / mute / help).
- `public/style.css` — royal Indian theme, card-flip and reveal animations, mobile-first layout.
- `public/app.js` — client: screens (home, lobby, roles, guess, result, final), Hindi/English text, Web Audio sounds, auto-reconnect.

## Rules implemented
- Roles each round: Raja 1000, Mantri 800, Sipahi 500, Chor 0 (shuffled server-side).
- Each player sees only their own role (tap-to-reveal card). Raja + Mantri are public.
- Raja presses "Mantri, catch the Chor!" (auto after 20 s). Mantri has 30 s to pick.
- Correct: everyone gets role points. Wrong or timeout: Mantri gets 0, Chor gets 800.
- Host chooses 5 / 10 / 15 rounds. Scoreboard after every round, podium at the end, "Play again" reuses the room.
- Refresh/disconnect: player id is kept in the URL hash (`#r=CODE&p=ID`) so they rejoin the same seat with score.

## Hosting
Any Node host that supports WebSockets (Render, Railway, Fly.io, etc.): start command `npm start`, port from `PORT` env var.
The server serves the frontend and the `/ws` endpoint from the same URL.
